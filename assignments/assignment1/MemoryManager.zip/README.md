*Driver.c:* Contains the driver program that sets the srand seed and calls the Memory Manager in MemoryManager.c


*Memory Manager:* get_running_count()

The Memory Manager file cotains the get_running_count() function that computes the number of times the median of a set of random arrays is divisible by 13. It also contains all the utility helper functions necessary to perform the routine.

*MemoryManager.h:* Makes the function get_running_count() visible to the driver program. 